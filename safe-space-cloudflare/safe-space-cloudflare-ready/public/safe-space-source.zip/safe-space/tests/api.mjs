import assert from 'node:assert/strict';
const tokens=Array.from({length:5},()=>crypto.randomUUID());
async function call(i,a){const r=await fetch((process.env.TEST_BASE_URL||'http://localhost:5173')+'/api/game',{method:'POST',headers:{'Content-Type':'application/json','x-player-token':tokens[i]},body:JSON.stringify(a)});return{status:r.status,...await r.json()};}
let r=await call(0,{type:'create',name:'API test A'});assert.equal(r.status,200,JSON.stringify(r));const code=r.game.code;
for(let i=1;i<4;i++){r=await call(i,{type:'join',code,name:'API test '+i});assert.equal(r.status,200);}
assert.equal((await call(4,{type:'join',code,name:'fifth'})).status,409);
assert.equal((await call(1,{type:'start',code})).status,400);
r=await call(0,{type:'start',code});assert.equal(r.status,200);
assert.equal((await call(1,{type:'roll',code})).status,400);
const results=await Promise.all([call(0,{type:'roll',code}),call(0,{type:'roll',code})]);assert.equal(results.filter(x=>x.status===200).length,1);
const states=await Promise.all([0,1,2,3].map(i=>call(i,{type:'sync',code})));assert.ok(states.every(x=>JSON.stringify(x.game)===JSON.stringify(states[0].game)));
console.log('PASS: four independent online sessions, fifth rejected, host-only start, turn authority, concurrent duplicate roll, shared state');
