# Safe Space • Campus Tycoon

บอร์ดเกมต้นฉบับสำหรับ 2–4 คนต่อห้อง กระดาน 24 ช่อง และโหมดผู้เล่น 1 คนกับบอท 3 ตัว ไม่ใช้เงินจริง

## สิ่งที่มี
- สร้างและเข้าห้องด้วยรหัส 6 ตัว แยกสถานะหลายห้องใน D1
- ลูกเต๋าสุ่มฝั่งเซิร์ฟเวอร์ ตรวจสิทธิ์เทิร์น ซื้อ/ประมูล/ค่าเยี่ยม/ชุดสี/พัฒนา 5 ระดับ/จำนอง/ไถ่ถอน/แลกเปลี่ยน/ล้มละลาย
- การ์ดสถานการณ์ 8 เรื่องและคำอธิบาย ไม่เก็บประสบการณ์บูลลี่ส่วนตัว
- จำกัดห้อง 4 คน อายุห้อง 24 ชั่วโมง เทิร์นออนไลน์ 90 วินาที เกม 30 รอบ
- คืนเซสชันจากเบราว์เซอร์เดิมผ่านปุ่มกลับเข้าห้องล่าสุด
- หน้าจอมือถือ, manifest และปุ่มเพิ่มหน้าจอหลักเมื่อเบราว์เซอร์รองรับ (ไม่ใช่แอป APK/EXE และไม่รองรับเล่นออฟไลน์หลังปิดเว็บ)

## รันพัฒนา
ต้องใช้ Node.js >=22.13 และ pnpm (packageManager ระบุใน package.json)

```sh
pnpm install
pnpm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_moaning_blade.sql
pnpm run dev
```

เปิด URL ที่คำสั่งแสดง ในเครื่องพัฒนาใช้ localhost การติดตั้ง PWA บนอุปกรณ์จริงต้องใช้ HTTPS
ชุดดาวน์โหลดไม่แนบ runtime state จึงใช้ portable profile ตามค่าเริ่มต้น

## เผยแพร่เอง
โค้ดเป็น Vinext + Cloudflare Workers + D1 ต้องกำหนดฐานข้อมูลใน deployment configuration และรัน migration ก่อนเปิดใช้ API ในแพลตฟอร์ม Sites ระบบจะจัดสรร binding DB และรัน migrations ให้ตาม `.openai/hosting.json` ชุดดาวน์โหลดลบ project_id ของเจ้าของเดิมแล้ว
อย่าคัดลอกข้อมูล session, `.dev.vars`, `.env`, `.wrangler`, node_modules หรือ Git credentials ไปยังโฮสต์สาธารณะ

## การทดสอบ
```sh
node --experimental-strip-types tests/game.test.ts
node --experimental-strip-types tests/route.test.mjs
pnpm exec tsc --noEmit
```
`tests/api.mjs` ใช้ URL ในตัวแปร TEST_BASE_URL (ค่าเริ่มต้น http://localhost:5173) และสร้างห้องทดสอบใหม่ ตรวจ 4 เซสชัน, ปฏิเสธคนที่ 5, สิทธิ์เจ้าของห้อง, เทิร์น, คำสั่งพร้อมกัน และสถานะตรงกัน

## การรองรับจำนวนมากและขอบเขตที่ต้องรู้
- API ตรวจสถานะจริงจากฐานข้อมูลและใช้ compare-and-swap ด้วย version ป้องกันการเขียนชนกัน
- ใช้ polling ทุก 2.5 วินาทีต่อแท็บที่เปิดอยู่ ไม่ใช่ WebSocket; 1,000 ผู้เล่นจะประมาณ 400 sync requests/วินาที ยังไม่ผ่าน load test ระดับนี้
- ไม่รับประกันจำนวนผู้เล่นพร้อมกัน ต้องวัด latency p95, errors, D1 reads/writes, CPU และค่าใช้จ่ายบนโฮสต์จริง
- ก่อนเปิดขนาดใหญ่ ควรใช้ Durable Object ต่อห้อง + WebSocket hibernation, rate limit ที่ขอบเครือข่าย, เก็บ metric, alarm และกระบวนการสำรอง/กู้คืน
- การจำกัดสร้าง 6 ห้องต่อ token ช่วยใช้งานปกติ ไม่ใช่การป้องกัน bot abuse แบบสมบูรณ์; token อยู่ใน localStorage และ hash บน server อย่าแชร์โปรไฟล์เบราว์เซอร์
- ห้องเก่าไม่เปิดให้อ่านหลัง 24 ชั่วโมง แต่ยังคงเป็นแถวในฐานข้อมูล ผู้ดูแลควรตั้งงานล้างแถวหมดอายุแบบมีขอบเขต
- หมดเวลา/บอทเดินเมื่อมี sync request ถ้าทุกคนปิดหน้าเว็บ ระบบไม่รัน timer เบื้องหลัง
- โฮสต์ใหม่บน Sites เริ่มแบบส่วนตัว การเล่นกับคนอื่นต้องเปิดสิทธิ์ผู้เข้าชมใน Sites ก่อน
- กติกาเป็นรุ่น Campus Tycoon ไม่ใช่สำเนาเกมการค้าทุกกติกา ไม่มีเงินจริง แชตเสียง ระบบบัญชีถาวร หรือ matchmaking

## ไฟล์หลัก
`lib/game.ts`: กฎเกมใช้ร่วมกัน (เซิร์ฟเวอร์เป็นผู้ตัดสินออนไลน์)
`app/api/game/route.ts`: ห้อง/เซสชัน/การเขียนแบบ atomic
`app/page.tsx`, `app/globals.css`: หน้าจอและกระดาน
`db/schema.ts`, `drizzle/`: schema และ migrations

ทดสอบ ณ 5 พฤศจิกายน 2026: กติกาจำลองบอทครบเกม 30 เกม, TypeScript/build, ตรวจหน้าเว็บด้วยเบราว์เซอร์ และ route integration 4 เซสชันโดยใช้ SQLite adapter จำลอง D1 (การเรียก API จาก shell ไป preview ถูกโครงสร้างพื้นฐานตัดการเชื่อมต่อ; สร้างห้องออนไลน์และเพิ่มบอทผ่านเบราว์เซอร์ได้จริง)
